- Pdf answer is in the Assignment1.pdf file
Algorithm is int he Q1.R file

- Answers to questions 2->7 can be found in Q2_7.R

- Modifications of the algorithm to the proposed standards can 
be found in the answers 2->7 subsections

- Each answer is separated by:
# ==================  Q# ==================
in the Q2_7.R file


- The Q2_7.R file will take a while to run (genrating all epochs for all
learning rates, hence it is advised that only sections are executed at a time)

- The Q2_7.R file requires the Q1.R file to run, as the algorithm is imported.



