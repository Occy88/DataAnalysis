- Pdf answer is in the report.pdf file
- HTML Equivalent (perhaps easier to read as it was produced by source code)
is located in report.html
- source code is in the source_code.rmd file

NOTE source code is an R-markdown file
It is compiled into an html document, but individual cells
can be executed (Just like jupyter notebook), given a normal IDE is used.